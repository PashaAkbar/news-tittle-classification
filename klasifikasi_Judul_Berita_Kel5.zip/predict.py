import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.text import Tokenizer
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import tensorflow as tf
import pickle

df = pd.read_csv('data/indonesian-news-title.csv')

max_features = 2000
max_len = 200


data = np.load('tokenized.npy',allow_pickle=True)
data = pd.Series(data)
joined = data.apply(lambda x: ' '.join(x))
tokenizer = Tokenizer(num_words=max_features, split=' ')
tokenizer.fit_on_texts(joined.values)

X = tokenizer.texts_to_sequences(joined.values)
X = pad_sequences(X, maxlen=max_len)
# Y = pd.get_dummies(df['category']).values

labels = ['finance','food','health','inet','oto','sport','travel']

filename = 'finalized_model.sav'
loaded_model = pickle.load(open(filename, 'rb'))


def prediksiModel(text):
    text_seq = tokenizer.texts_to_sequences([text])
    print(text_seq)
    text_seq = pad_sequences(text_seq, maxlen=200)
    pred = loaded_model.predict(text_seq)[0]
    print(text_seq)
    predict = labels[np.argmax(pred)]
    print('Text:', text)
    print(predict)
    st.subheader("Hasil Sentimen: "+ predict)
    

st.title('Klasifikasi Berita Menggunakan LSTM')


teks = st.text_input("Masukkan Teks: ")
clicked = st.button("Prediksi Teks")

if clicked:
    prediksiModel(teks)

